# External Diligence Validation

- `generated_at_utc`: `2026-06-02T04:57:09.006474+00:00`
- `status`: `POV_FINAL_PACKAGE_BLOCKED_WITH_EVIDENCE`
- `cold_clone_status`: `COLD_CLONE_REPLAY_FAIL`
- `claim_red_team_status`: `CLAIM_RED_TEAM_FAIL`
- `view_count`: `6`
- `tier_manifest_count`: `3`
- `scorecard_exists`: `True`
- `sqlite_exists`: `True`
- `wetlab_exists`: `True`
- `executive_packet_exists`: `True`
- `structural_packet_exists`: `True`
- `medchem_packet_exists`: `True`
- blockers:
  - `cold_clone_replay_failed`
  - `claim_red_team_failed`
