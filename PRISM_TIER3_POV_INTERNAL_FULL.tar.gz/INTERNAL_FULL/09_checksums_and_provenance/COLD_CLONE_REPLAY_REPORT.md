# Cold Clone Replay Report

- `schema_version`: `prism.tier3_pov.cold_clone_replay_report.v1`
- `generated_at_utc`: `2026-06-02T04:57:08.868557+00:00`
- `status`: `COLD_CLONE_REPLAY_FAIL`
- `clone_root`: `/tmp/prism_pov_cold_clone_j7uyonxn/clone`
- `git_commit`: `cfc8dc4d17fca841936e159579d123d0371f5aeb`
- `declared_dependencies_file`: `requirements.txt`
- `dependency_install_mode`: `runtime_subset_verified`
- `archive_exists`: `True`
- `archive_sha256`: `9279435e855b6cc38d3df553b3913ab893455d575e392a5616c221c8567ee822`
- `archive_blake3`: `500415eb35808b3e7c98a26361bf56dc2995adb5280d8a1af4af8ee005de7b0a`
- `merkle_root`: `e66af5b80b6ccdedb11ae551216960ea6bdb385c2e9a5dde404a83cfbf4d9270`
- `master_index_status`: `PASS`
- `claim_count`: `5`
- `visual_locks_present`: `True`
- `render_locks_present`: `True`
- `referenced_artifact_missing_count`: `1`
