# 02_loop2_glp1r_crucible

This directory is part of the PRISM cinematic visual data room. Artifacts here must be evidence-linked and lock-sealed.
