# 01_authority_and_lineage

This directory is part of the PRISM cinematic visual data room. Artifacts here must be evidence-linked and lock-sealed.
