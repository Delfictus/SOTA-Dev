# Visual Source Registry

- generated_at_utc: `2026-06-02T04:15:07Z`
- source_count: `12`
- blocked_source_count: `0`

| source_id | status | path |
| --- | --- | --- |
| `loop2_authority_summary` | `PASS` | `campaigns/glp1r_aleniglipron/tier3_pov/staged_runs/tier3-pov-20260529T184259Z/loop2/aggregation/strict_loop2_aggregation_20260531T230545Z/authority_deliverables/loop2_authority_deliverable_build_summary.json` |
| `loop2_variant_resilience_map` | `PRESENT` | `campaigns/glp1r_aleniglipron/tier3_pov/staged_runs/tier3-pov-20260529T184259Z/loop2/aggregation/strict_loop2_aggregation_20260531T230545Z/authority_deliverables/loop2_variant_resilience_map.parquet` |
| `loop2_motif_attribution_summary` | `PRESENT` | `campaigns/glp1r_aleniglipron/tier3_pov/staged_runs/tier3-pov-20260529T184259Z/loop2/aggregation/strict_loop2_aggregation_20260531T230545Z/authority_deliverables/loop2_motif_attribution_summary.parquet` |
| `loop25_authority_summary` | `PASS` | `campaigns/glp1r_aleniglipron/tier3_pov/staged_runs/tier3-pov-20260529T184259Z/loop2_5_selectivity/authority/reconcile_loop25_20260601T080211Z_rowfix/loop25_r2_authority_summary.json` |
| `loop25_scientific_decision_layer` | `PASS_PROXY_DECISION_LAYER` | `campaigns/glp1r_aleniglipron/tier3_pov/staged_runs/tier3-pov-20260529T184259Z/loop2_5_selectivity/scientific_decision_layer_full_540/loop25_scientific_decision_layer_summary.json` |
| `loop25_cross_receptor_selectivity_index` | `PRESENT` | `campaigns/glp1r_aleniglipron/tier3_pov/staged_runs/tier3-pov-20260529T184259Z/loop2_5_selectivity/scientific_decision_layer_full_540/loop25_cross_receptor_selectivity_index.parquet` |
| `loop3_authority_summary` | `PASS` | `campaigns/glp1r_aleniglipron/tier3_pov/staged_runs/tier3-pov-20260529T184259Z/loop3/authority/reconcile_loop3_final_20260601T163108Z/loop3_final_row_authority_summary.json` |
| `loop3_authority_table` | `PRESENT` | `campaigns/glp1r_aleniglipron/tier3_pov/staged_runs/tier3-pov-20260529T184259Z/loop3/authority/reconcile_loop3_final_20260601T174443Z/loop3_final_row_authority_table.parquet` |
| `loop3_row_metrics` | `PRESENT` | `campaigns/glp1r_aleniglipron/tier3_pov/staged_runs/tier3-pov-20260529T184259Z/loop3/materialization/loop3_row_metrics.parquet` |
| `loop3_chronology_tensor` | `PRESENT` | `campaigns/glp1r_aleniglipron/tier3_pov/staged_runs/tier3-pov-20260529T184259Z/loop3/chronology/loop3_transition_chronology_tensor.parquet` |
| `loop3_motif_failure_attribution` | `PRESENT` | `campaigns/glp1r_aleniglipron/tier3_pov/staged_runs/tier3-pov-20260529T184259Z/loop3/motifs/loop3_motif_failure_attribution.parquet` |
| `master_claim_index` | `PRESENT` | `final_pov_package/00_control/POV_MASTER_CLAIM_INDEX.json` |
