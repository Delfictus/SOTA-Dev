# Visual Phase 1/2 Build Summary

- status: `CINEMATIC_DATA_ROOM_PHASE12_BUILT`
- primary_3d_renderer: `molstar`
- blocked_source_count: `0`
- lock_count: `13`
- valid_lock_count: `13`
