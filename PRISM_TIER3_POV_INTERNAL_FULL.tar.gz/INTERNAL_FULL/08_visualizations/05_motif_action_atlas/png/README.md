# 05_motif_action_atlas/png

This directory is part of the PRISM cinematic visual data room. Artifacts here must be evidence-linked and lock-sealed.
