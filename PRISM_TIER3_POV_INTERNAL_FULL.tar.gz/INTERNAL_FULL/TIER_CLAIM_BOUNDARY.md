Internal full tier with preserved full technical detail.
