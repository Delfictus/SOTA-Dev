# DSTW Full-Leverage Closeout State

- status: `DSTW_CLOSEOUT_STATE_FROZEN`
- control_number: `PRISM-T3POV-20260529T184259Z-90FFAE25ED5F`
- run_id: `tier3-pov-20260529T184259Z`
- git_commit: `cfc8dc4d17fca841936e159579d123d0371f5aeb`
- loop2_authority_status: `PASS`
- loop2_scientific_layer_status: `PASS_PROXY_DECISION_LAYER`
- loop2.5_authority_status: `PASS`
- loop2.5_scientific_layer_status: `PASS_PROXY_DECISION_LAYER`
- loop3_materialization_status: `LOOP3_POSTMD_MATERIALIZED`
- loop3_admitted_row_count: `299`
- loop3_metric_row_count: `299`
- visual_build_status: `CINEMATIC_DATA_ROOM_PHASE12_BUILT`
- visual_validation_status: `PASS`
- visual_merkle_root: `None`
- package_control_freshness_status: `FRESH`
- phase_manifold_provenance_status: `PHASE_MANIFOLD_PROVENANCE_CLOSED`
- unresolved_blockers: `0`
