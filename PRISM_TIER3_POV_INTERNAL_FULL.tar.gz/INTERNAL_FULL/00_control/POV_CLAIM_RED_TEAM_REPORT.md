# POV Claim Red-Team Report

- `CRITICAL` `final_pov_package/00_control/POV_CLAIM_BOUNDARY.md` `Clinical efficacy wording is forbidden.`
- `CRITICAL` `final_pov_package/00_control/POV_CLAIM_BOUNDARY.md` `Toxicity proof language is forbidden.`
- `CRITICAL` `final_pov_package/00_control/POV_CLAIM_BOUNDARY.md` `Dual-agonism proof language is forbidden.`
- `HIGH` `final_pov_package/00_control/POV_CLAIM_BOUNDARY.md` `Exact thermodynamics wording is forbidden.`
- `HIGH` `06_translational_dossiers/MIXED_FINDING_SCIENTIFIC_SYNTHESIS.md` `missing_claim_evidence:package.mixed_result`
