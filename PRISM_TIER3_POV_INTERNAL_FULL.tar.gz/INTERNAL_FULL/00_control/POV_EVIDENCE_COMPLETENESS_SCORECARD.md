# POV Evidence Completeness Scorecard

- `incumbent liability`: `MODERATE_COMPUTATIONAL_EVIDENCE` claim_allowed=`True`
- `competitor comparison`: `LIMITED_COMPUTATIONAL_EVIDENCE` claim_allowed=`True`
- `de novo outperformer`: `LIMITED_COMPUTATIONAL_EVIDENCE` claim_allowed=`False`
- `scaffold rescue`: `MODERATE_COMPUTATIONAL_EVIDENCE` claim_allowed=`True`
- `PGx resilience`: `LIMITED_COMPUTATIONAL_EVIDENCE` claim_allowed=`False`
- `active/inactive portability`: `LIMITED_COMPUTATIONAL_EVIDENCE` claim_allowed=`True`
- `Loop 2.5 selectivity`: `MODERATE_COMPUTATIONAL_EVIDENCE` claim_allowed=`True`
- `pipeline expansion`: `LIMITED_COMPUTATIONAL_EVIDENCE` claim_allowed=`False`
- `Loop 3 falsification`: `STRONG_COMPUTATIONAL_EVIDENCE` claim_allowed=`True`
- `motif attribution`: `LIMITED_COMPUTATIONAL_EVIDENCE` claim_allowed=`False`
- `wet-lab routing`: `LIMITED_COMPUTATIONAL_EVIDENCE` claim_allowed=`True`
- `med-chem recommendations`: `LIMITED_COMPUTATIONAL_EVIDENCE` claim_allowed=`True`
