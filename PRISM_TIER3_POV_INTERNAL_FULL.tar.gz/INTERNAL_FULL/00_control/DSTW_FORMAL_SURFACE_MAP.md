# DSTW Formal Surface Map

- `phase_manifold_provenance` -> `phase-manifold ranker evidence` [OBSERVED_EXECUTION_EVIDENCE]
- `loop2_c0_c6_proxy` -> `C0 transfer operator / C6 restricted Dirichlet survival / C6.7 Perron robustness` [PROXY_BOUNDED]
- `loop25_selectivity_proxy` -> `selectivity proxy / retained federated operators` [PROXY_BOUNDED]
- `loop3_chronology` -> `C2 chronology/eigenvalue decay / C4 timescale validity` [PROXY_BOUNDED]
- `loop3_motif_attribution` -> `motif attribution` [PROXY_BOUNDED]
- `ghost_site_metadata` -> `C1 metastable state extraction / C3 bisimulation-lumpability support metadata` [OBSERVED_OR_BOUNDARY_DECLARED]
- `wetlab_routing` -> `wet-lab routing` [ACTIONABLE_ROUTING]
