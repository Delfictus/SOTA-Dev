# POV Data Room SQL Queries

- show all claims about scaffold rescue:
  `select * from claims where claim_text like '%scaffold-rescue%';`
- show all evidence supporting CAND_ALENI_SCAFFOLD_RESCUE_V2:
  `select * from rows where molecule='CAND_ALENI_SCAFFOLD_RESCUE_V2';`
- show all Loop 3 falsification artifacts:
  `select * from artifacts where path like '%loop3%';`
- show all wet-lab assay recommendations:
  `select * from assays;`
- show all claims with proxy-bounded evidence:
  `select * from claims where exact_or_proxy like 'PROXY%';`
- show all molecule-specific motif findings:
  `select * from motifs;`
- show all redacted artifacts:
  `select * from artifacts where category='redacted';`
