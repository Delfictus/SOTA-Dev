# POV Claim Boundary

Allowed:
- dynamic-state proxy wording
- mixed-finding wording
- wet-lab routing and falsification planning

Forbidden:
- clinical efficacy
- toxicity proof
- dual-agonism proof
- exact thermodynamics
- exact C6/C6.7 proof where only proxy surfaces exist
