# DSTW Proxy Boundary Ledger

- `loop2_c0_c6_proxy`: allowed `C6/C6.7-inspired dynamic-state evidence` | forbidden `exact C6 or exact C6.7 proof`
- `loop25_selectivity_proxy`: allowed `cross-receptor dynamic-state selectivity proxy` | forbidden `biochemical selectivity proof`
- `loop3_chronology`: allowed `failure chronology surface` | forbidden `exact spectral proof`
- `loop3_motif_attribution`: allowed `motif blocker panel / no fake highlights` | forbidden `atom-exact motif attribution where mapping is blocked`
- `ghost_site_metadata`: allowed `ghost metadata completeness boundary` | forbidden `per-site ghost chronology where metadata is partial`
- `wetlab_routing`: allowed `validation order of operations` | forbidden `wet-lab outcome certainty`
