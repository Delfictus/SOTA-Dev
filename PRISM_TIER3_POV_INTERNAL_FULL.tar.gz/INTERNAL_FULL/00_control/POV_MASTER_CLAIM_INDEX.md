# POV Master Claim Index

- `loop3.incumbent_resilience_leader`: ALENI_PARENT leads the current Loop 3 falsification summary. [PROXY_BOUNDED]
- `loop25.prism_selectivity_leader`: CAND_015_BCCDA098 is the Loop 2.5 selectivity-leading PRISM-origin profile, but it remains liability-classed. [PROXY_BOUNDED]
- `loop2.scaffold_rescue_lane`: CAND_ALENI_SCAFFOLD_RESCUE_V2 remains the best scaffold-rescue lane, but not the overall winner narrative. [PROXY_BOUNDED]
- `package.mixed_result`: This POV found a mixed result and should be used as a decision map rather than a forced winner package. [ACTIONABLE_SYNTHESIS]
- `motif.boundary`: Loop 3 motif output is blocker-class and no atom-level motif claim is allowed in this package. [PROXY_BOUNDED]
