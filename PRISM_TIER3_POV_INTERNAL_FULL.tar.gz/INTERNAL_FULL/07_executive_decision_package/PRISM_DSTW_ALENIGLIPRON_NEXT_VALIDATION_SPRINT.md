# PRISM-DSTW Aleniglipron Next Validation Sprint

Thesis:
pay for the validation sprint because the package already narrows the decision tree to a tractable set of ambiguity-killing assays.

Priority order:
1. Calibrate incumbent baseline with cAMP and mini-G.
2. Challenge CAND_015_BCCDA098 with cross-receptor pathway assays.
3. Test scaffold rescue with washout/rechallenge and nanoDSF.
4. Run HDX-MS only on the narrowed finalists.

Stop conditions:
- selectivity leader confirms liability
- scaffold rescue fails stabilization and washout checks
- benchmark dominates unexpectedly
