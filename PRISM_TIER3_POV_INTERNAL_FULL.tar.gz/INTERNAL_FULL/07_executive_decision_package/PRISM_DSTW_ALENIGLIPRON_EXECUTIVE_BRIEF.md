# PRISM-DSTW Aleniglipron Executive Brief

PRISM-DSTW provides a system-wide dynamic-state map before wet-lab narrowing. This POV does not force a winner story; it shows where aleniglipron appears robust, where it appears vulnerable, and where PRISM-origin rescue logic is promising or limited.

The mixed finding increases credibility because the package preserves negative evidence and claim boundaries instead of laundering everything into a success narrative.

Structure should care before Phase 3 because this package identifies which ambiguous computational findings are worth paying to validate, and which candidates should not absorb additional chemistry or assay budget.

## Wet-Lab Routing

| area | first experiments | purpose |
| --- | --- | --- |
| incumbent calibration | cAMP, mini-G | confirm Loop 3 incumbent lead |
| selectivity leader challenge | arrestin/internalization, HDX-MS | decide whether liability is real |
| scaffold rescue | washout/rechallenge, nanoDSF | decide whether rescue merits chemistry follow-up |

## Scaffold-Rescue Actions

| candidate | action | reason |
| --- | --- | --- |
| CAND_ALENI_SCAFFOLD_RESCUE_V2 | validate, do not overclaim | best rescue lane, not overall winner |
| CAND_RESCUE_PGX | do not advance yet | weakest combined evidence |

## Selectivity / Pipeline Hypotheses

| candidate | hypothesis | boundary |
| --- | --- | --- |
| CAND_015_BCCDA098 | leading selectivity proxy may still carry cross-receptor liability | not a biochemical selectivity proof |
| ORFORGLIPRON_BENCHMARK | remains mixed comparator | not a disqualifying benchmark result |
