# Tier-3 PoV Executive Package Summary

This package is claim-bounded. It is not a naive leaderboard.

- `loop2.best_de_novo`: Loop 2 best de novo proxy profile is CAND_GENERALIST_V2 [DERIVED_PROXY_DECISION_LAYER]
- `loop2.best_scaffold_rescue`: Loop 2 best scaffold rescue proxy profile is CAND_ALENI_SCAFFOLD_RESCUE_V2 [DERIVED_PROXY_DECISION_LAYER]
- `loop25.authority_closed`: Loop 2.5 authority admit count is 540 / 540 [OBSERVED_EXECUTION_AUTHORITY]
- `loop25.best_selective_glp1r_profile`: Loop 2.5 best selective GLP-1R proxy profile is CAND_015_BCCDA098 [DERIVED_CROSS_RECEPTOR_PROXY]
- `loop3.authority_closed`: Loop 3 authority admit count is None / 300 [OBSERVED_EXECUTION_AUTHORITY]
