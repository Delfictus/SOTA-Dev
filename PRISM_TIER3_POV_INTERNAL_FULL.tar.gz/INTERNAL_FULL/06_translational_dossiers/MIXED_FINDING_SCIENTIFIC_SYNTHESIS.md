# Mixed Finding Scientific Synthesis

This POV found a mixed result. The mixed result is valuable because it maps risk and rescue boundaries rather than forcing a false winner story.

## Incumbent

`ALENI_PARENT` appears strongest in Loop 3 falsification and resilience. It remains vulnerable on selectivity interpretation because its Loop 2.5 profile is mixed/unresolved rather than cleanly selective.

## PRISM-Origin Candidates

`CAND_015_BCCDA098` is the Loop 2.5 selectivity leader, but it is still classified `OFF_AXIS_OR_SELECTIVITY_LIABILITY`. `CAND_ALENI_SCAFFOLD_RESCUE_V2` remains the useful scaffold-rescue lane, but it does not outrank the incumbent overall.

`CAND_RESCUE_PGX` should not be advanced from the current package because it ranks weakest across the current combined evidence and does not justify further spend before wet-lab validation.

## Why The Mixed Finding Matters

The value is not “PRISM always wins.” The value is that PRISM-DSTW surfaces where aleniglipron looks robust, where it looks vulnerable, and where PRISM-origin rescue logic is promising but still bounded.

## Wet-Lab Deciders

- cAMP and mini-G to anchor pathway-level rankings
- arrestin/internalization to test the selectivity-leader liability
- HDX-MS and nanoDSF to challenge the dynamic-state interpretation
- washout/rechallenge and variant panel to decide whether scaffold rescue is worth paid follow-up

## Structure Validation Sprint

The paid sprint case is a decision-map case: validate the incumbent risk/rescue map, test whether the selectivity leader is disqualified by liability, and decide whether scaffold rescue warrants chemistry expansion.
