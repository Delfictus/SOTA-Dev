# DSTW Post-MD Handoff Surface

- status: `DSTW_POSTMD_HANDOFF_SURFACE_BUILT`
- evidence_items: `1311`
- resolved_machine_readable_count: `1310`
- proxy_boundary_count: `1`
