# Deferred / Manual Items Resolved

- `md_evidence_complete_postmd_deferred` rows were lifted into machine-readable DSTW surfaces through scientific row tables plus canonical materialization records.
- `Path B / manual aggregation required` is retained as provenance, but not as an unresolved delivery blocker where row-level tables and canonical materialization outputs exist.
- remaining boundaries are declared in `dstw_remaining_proxy_boundaries.json`.
