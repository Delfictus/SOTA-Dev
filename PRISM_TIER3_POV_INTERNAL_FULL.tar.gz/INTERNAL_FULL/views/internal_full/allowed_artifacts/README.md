# Allowed Artifacts

Use `evidence_links.json` for package-relative artifact navigation.
