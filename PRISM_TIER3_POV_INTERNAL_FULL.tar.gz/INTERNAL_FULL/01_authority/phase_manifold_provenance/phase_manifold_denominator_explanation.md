# Phase-Manifold Denominator Explanation

- Loop 2 admitted rows: `480`
- Loop 2.5 admitted rows: `540`
- Loop 3 admitted rows: `289`
- Total admitted rows audited: `1309`

Rejected rows are excluded from the closure denominator.
