External-safe tier.
