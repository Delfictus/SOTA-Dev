# One Meeting Packet

30-second thesis:
PRISM-DSTW does not claim a universal winner. It gives Structure a dynamic risk/rescue map before Phase 3 spend, with specific wet-lab tests that can kill or confirm the ambiguous findings quickly.

Why Structure should care before Phase 3:
the package identifies where aleniglipron is resilient, where selectivity risk may sit, and whether scaffold rescue is real enough to justify additional chemistry.

What PRISM surfaced:
- incumbent resilience lead in Loop 3
- PRISM-origin selectivity lead with liability boundary
- scaffold-rescue lane that is useful but not decisively superior
- negative evidence preserved rather than hidden

Top incumbent liability:
unresolved selectivity interpretation outside the falsification lead.

Top scaffold-rescue opportunity:
validate CAND_ALENI_SCAFFOLD_RESCUE_V2 without forcing a winner narrative.

Top de novo candidate:
CAND_015_BCCDA098, bounded by liability classification.

Top selectivity/pipeline insight:
the selective-looking proxy is valuable precisely because it may expose expansion risk early.

Top falsification result:
ALENI_PARENT currently ranks first in Loop 3 falsification.

First 5 wet-lab experiments:
- WL01 cAMP
- WL02 mini-G
- WL03 arrestin/internalization
- WL04 washout/rechallenge
- WL05 HDX-MS

Paid sprint proposal:
a short validation sprint should resolve whether the selectivity leader is disqualified, whether scaffold rescue is real, and whether the incumbent risk map is strong enough to justify broader partnership diligence.
