# Open And Inspect

What to look at: phase-manifold-ranked binding surfaces, chronology-linked stress scenes, and the comparison between incumbent, scaffold-rescue, and selectivity-lead contexts.

Why it matters: these scenes anchor the decision map rather than a winner story.

Mol* / scene links:
- interactive scenes are tracked in the package manifest; use the visualization directories directly

Falsification route:
- HDX-MS for dynamic-state challenge
- nanoDSF for stabilization challenge
- mini-G / arrestin for pathway readout challenge
