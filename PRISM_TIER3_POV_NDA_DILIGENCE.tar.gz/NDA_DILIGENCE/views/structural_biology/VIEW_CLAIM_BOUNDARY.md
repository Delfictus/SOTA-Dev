# View Claim Boundary

dynamic-state interpretation only; no exact thermodynamics
