# Wet-Lab Top 10 Experiments

1. `WL01` `cAMP` `ALENI_PARENT` `GLP1R_W297R`
1. `WL02` `mini-G` `ALENI_PARENT` `GLP1R_C226R / N182D / R190Q / W297R panel`
1. `WL03` `arrestin/internalization` `CAND_015_BCCDA098` `GLP1R_WT + GCGR/GIPR comparison`
1. `WL04` `washout/rechallenge` `CAND_ALENI_SCAFFOLD_RESCUE_V2` `GLP1R_WT + variant stress panel`
1. `WL05` `HDX-MS` `ALENI_PARENT / CAND_ALENI_SCAFFOLD_RESCUE_V2 / CAND_015_BCCDA098` `GLP1R_WT + W297R`
1. `WL06` `nanoDSF` `ALENI_PARENT / CAND_ALENI_SCAFFOLD_RESCUE_V2` `GLP1R_WT + T149M + A316T`
1. `WL07` `variant panel` `ORFORGLIPRON_BENCHMARK` `GLP1R_WT + variant stress panel`
1. `WL08` `cAMP` `CAND_GENERALIST_V2` `GLP1R_WT + off-axis panel`
1. `WL09` `mini-G` `CAND_RESCUE_PGX` `GLP1R_WT + PGx-linked variants`
1. `WL10` `HDX-MS` `CAND_015_BCCDA098 / ORFORGLIPRON_BENCHMARK` `GCGR + GIPR comparative panel`
