# Wet-Lab Validation Decision Tree

- `WL01` `cAMP` -> anchors incumbent benchmark and calibrates proxy-to-assay mapping
- `WL02` `mini-G` -> tests whether computational falsification rank survives pathway-focused readout
- `WL03` `arrestin/internalization` -> decides whether the PRISM selectivity leader is advanceable or not
- `WL04` `washout/rechallenge` -> tests whether scaffold rescue is worth chemistry follow-up
- `WL05` `HDX-MS` -> directly challenges the dynamic-state map
- `WL06` `nanoDSF` -> filters scaffold-rescue work before broader profiling
- `WL07` `variant panel` -> keeps benchmark narrative honest before BD framing
- `WL08` `cAMP` -> decides whether generalist remains a hypothesis or gets deprioritized
- `WL09` `mini-G` -> supports explicit non-advance recommendation
- `WL10` `HDX-MS` -> decides whether selectivity expansion is real or proxy-only
