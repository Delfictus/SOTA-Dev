# View Claim Boundary

validation routing only; no assay outcome certainty
