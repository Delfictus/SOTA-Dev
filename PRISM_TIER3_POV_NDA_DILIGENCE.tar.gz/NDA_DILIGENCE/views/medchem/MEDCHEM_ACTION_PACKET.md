# Med-Chem Action Packet

Keep motifs:
- motifs associated with incumbent-like durability surfaces, subject to wet-lab confirmation

Remove motifs:
- none with atom-level certainty; atom-mapping is blocked in the current Loop 3 motif layer

Modify motifs:
- scaffold-rescue vectors around CAND_ALENI_SCAFFOLD_RESCUE_V2 that preserve the aleniglipron core

Avoid motifs:
- patterns associated with CAND_RESCUE_PGX and the strongest liability-classed selectivity excursions

Scaffold rescue vectors:
- preserve core, challenge exit vectors only, do not destroy the parent scaffold just to recover activity

Negative motif registry:
- current negative evidence is blocker-class rather than atom-exact
