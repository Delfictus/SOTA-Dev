# View Claim Boundary

route guidance only; no atom-exact motif claims where blocked
